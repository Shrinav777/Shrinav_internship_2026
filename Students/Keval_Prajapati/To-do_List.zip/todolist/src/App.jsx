import { useState } from "react";
import "./App.css";

function App() {
  const [task, setTask] = useState([
    "Read Book","Complete React Assignment","Drink Water","Call Friend","Practice Coding","Go for Walk"
  ]);

  const [newTask, setNewTask] = useState("");

  function AddTask() {
    if (newTask.trim() === "") {
      alert("Please enter a task");
      return;
    }

    setTask([...task, newTask]);
    setNewTask("");
  }

  function deleteTask(index) {
    setTask(task.filter((t, i) => i !== index));
  }

  return (
    <div className="container">
      <h1>Daily Planner</h1>

      <div className="inputBox">
        <input
          type="text"
          placeholder="Add new activity"
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
        />

        <button onClick={AddTask}>Add</button>
      </div>

      <ul>
        {task.map((t, i) => (
          <li key={i}>
            <span>{t}</span>

            <button onClick={() => deleteTask(i)}>
              Remove
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;