import React, { useState, useRef } from 'react';

function App() {
  const [displaySeconds, setDisplaySeconds] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const intervalId = useRef(null);

  const slowSpeed = (87 / 60) * 1000;

  const updateDisplay = () => {
    let mins = Math.floor(displaySeconds / 60);
    let secs = displaySeconds % 60;
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  const startTimer = () => {
    if (isRunning) return;
    setIsRunning(true);
    intervalId.current = setInterval(() => {
      setDisplaySeconds((prev) => prev + 1);
    }, slowSpeed);
  };

  const pauseTimer = () => {
    if (!isRunning) return;
    clearInterval(intervalId.current);
    intervalId.current = null;
    setIsRunning(false);
  };

  const stopTimer = () => {
    clearInterval(intervalId.current);
    intervalId.current = null;
    setIsRunning(false);
    setDisplaySeconds(0);
  };

  return (
    <>
      <div className="timer-card">
        <div className="display-container">
          <div className="timer-display">{updateDisplay()}</div>
        </div>

        <div className="controls">
          <div className="row-buttons">
            <button className="btn btn-start" onClick={startTimer}>
              <span className="material-symbols-rounded">play_arrow</span>START
            </button>
            <button className="btn btn-stop" onClick={pauseTimer}>
              <span className="material-symbols-rounded">pause</span>STOP
            </button>
          </div>
          <button className="btn btn-reset" onClick={stopTimer}>
            <span className="material-symbols-rounded">refresh</span>RESET
          </button>
        </div>

        <div className="hourglass">
          <div className="sand-top"></div>
          <div className="sand-stream"></div>
          <div className="sand-bottom"></div>
        </div>
      </div>

      <div className="marquee-container">
        <div className="marquee-track">
          <div className="marquee-content">
            રામ રામ &nbsp;&nbsp; રામ રામ &nbsp;&nbsp; રામ રામ &nbsp;&nbsp; રામ રામ &nbsp;&nbsp; રામ રામ &nbsp;&nbsp; રામ રામ &nbsp;&nbsp; રામ રામ &nbsp;&nbsp; રામ રામ &nbsp;&nbsp;
          </div>
          <div className="marquee-content">
            રામ રામ &nbsp;&nbsp; રામ રામ &nbsp;&nbsp; રામ રામ &nbsp;&nbsp; રામ રામ &nbsp;&nbsp; રામ રામ &nbsp;&nbsp; રામ રામ &nbsp;&nbsp; રામ રામ &nbsp;&nbsp; રામ રામ &nbsp;&nbsp;
          </div>
        </div>
      </div>
    </>
  );
}

export default App;
